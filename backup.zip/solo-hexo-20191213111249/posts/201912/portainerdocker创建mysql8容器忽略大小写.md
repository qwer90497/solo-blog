title: portainer,docker创建mysql8容器,忽略大小写
date: '2019-12-11 15:11:00'
updated: '2019-12-11 15:27:53'
tags: [docker, portainer, mysql8]
permalink: /articles/2019/12/11/1576048260353.html
---
拉取mysql镜像  
docker pull mysql:8

创建volume 两个 mysql_data mysql_conf 分别挂载数据和配置文件
![image.png](https://img.hacpai.com/file/2019/12/image-06514975.png)

创建wx_mysql 
使用mysql:8镜像
映射端口 3307 3306
![image.png](https://img.hacpai.com/file/2019/12/image-4ef62d7a.png)
![image.png](https://img.hacpai.com/file/2019/12/image-0c922548.png)

VOLUMES 挂载目录配置
/etc/mysql mysql_conf
/var/lib/mysql mysql_data
![image.png](https://img.hacpai.com/file/2019/12/image-fe72642d.png)

EVN 环境配置 root密码和time_zone时区
TZ Asia/Shanghai
MYSQL_ROOT_PASSWORD 111111
![image.png](https://img.hacpai.com/file/2019/12/image-3a0a7067.png)

发布容器deploy the conatiner
![image.png](https://img.hacpai.com/file/2019/12/image-2aa293ff.png)

停止容器
![image.png](https://img.hacpai.com/file/2019/12/image-9d357e71.png)

修改mysql配置文件在挂载的volume mysql_conf/_data中找到my.cnf
![image.png](https://img.hacpai.com/file/2019/12/image-cd3355d8.png)

修改大小写忽略,并指定加密规则为mysql_native_password
在[mysqld]下面添加
default_authentication_plugin = mysql_native_password
lower_case_table_names=1
![image.png](https://img.hacpai.com/file/2019/12/image-c4d56b13.png)

删除volume mysql_data/_data下的数据(删除mysql数据让mysql重新初始化)
![image.png](https://img.hacpai.com/file/2019/12/image-4d47b9bf.png)

重新发布容器deploy the conatiner
![image.png](https://img.hacpai.com/file/2019/12/image-fde2bfdf.png)


如果没起来重复上述操作删除数据继续发布容器
