title: nginx无权访问tomcat下的项目文件
date: '2019-10-23 00:48:12'
updated: '2019-10-23 00:48:12'
tags: [待分类]
permalink: /articles/2019/10/23/1571762892236.html
---
nginx无权访问tomcat下的项目文件

---
**遇到问题:**

用nginx代理war项目下的静态文件,war部署在tomcat中

页面请求静态资源提示403 Forbidden

**解决:**

tomcat解压的项目文件权限问题，需要修改  

修改 tomcat/bin 目录下的 catlina.sh，找到

```
# Set UMASK unless it has been overridden
if [ -z "$UMASK" ]; then
    UMASK="0027"
fi
umask $UMASK

``` 
将0027改成0022，删除已经解压出来的项目文件,重启tomcat

```
# Set UMASK unless it has been overridden
if [ -z "$UMASK" ]; then
    UMASK="0022"
fi
umask $UMASK

``` 
